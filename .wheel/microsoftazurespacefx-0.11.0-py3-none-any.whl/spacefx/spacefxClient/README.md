This holds the dlls from the sdk-dotnet library.  It will be empty in source control, but will have the dlls when the wheel is generated.
