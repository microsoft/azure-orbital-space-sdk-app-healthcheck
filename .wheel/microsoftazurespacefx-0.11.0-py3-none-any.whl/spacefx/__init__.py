from spacefx import protos
from spacefx import _sdk_client
from spacefx import client
from spacefx import logging
from spacefx import position
from spacefx import link
from spacefx import sensor

logger = logging.__SpaceFxLogger
